df_regions = pd.read_csv(os.path.join('data', 'regions.csv'))
df_regions.head()
