sns.catplot(data=df, x='Pclass', y='Survived', hue='Sex', kind='bar')
