regions_vote = df.groupby(['code_y', 'name_y']).sum()
regions_vote
