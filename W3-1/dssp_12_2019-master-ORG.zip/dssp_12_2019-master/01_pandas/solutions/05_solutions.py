df[(df['Sex'] == 'male') & (df['Age'] > 60)].shape[0]
