df = pd.DataFrame({'Country Name': country_name,
                   2015: gdp_2015,
                   2017: gdp_2017},
                  index=country_code)
df
