df['Fare'].max()
