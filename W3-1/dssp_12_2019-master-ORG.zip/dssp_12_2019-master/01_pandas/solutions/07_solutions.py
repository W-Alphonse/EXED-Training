df['Fare'].median()
