df.groupby('Sex')['Age'].hist(alpha=0.4);
