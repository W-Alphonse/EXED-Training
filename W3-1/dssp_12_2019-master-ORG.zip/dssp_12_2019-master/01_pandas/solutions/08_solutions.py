df['Survived'].sum() / df.shape[0]
