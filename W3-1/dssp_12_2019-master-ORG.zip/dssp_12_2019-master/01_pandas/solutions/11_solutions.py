df[df['Sex'] == 'male']['Age'].mean()
