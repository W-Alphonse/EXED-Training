df_departments = pd.read_csv(os.path.join('data', 'departments.csv'))
df_departments.head()
