sns.violinplot(data=df, y='Fare', x='Survived', hue='Sex', split=True)
