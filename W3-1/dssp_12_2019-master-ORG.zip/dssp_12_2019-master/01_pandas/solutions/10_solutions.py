((df['Age'] > 60) & (df['Sex'] == 'male')).value_counts()[True]
