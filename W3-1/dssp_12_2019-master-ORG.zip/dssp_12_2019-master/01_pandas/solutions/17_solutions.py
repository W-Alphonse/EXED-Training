df.groupby('Pclass')['Survived'].mean().plot.bar()
