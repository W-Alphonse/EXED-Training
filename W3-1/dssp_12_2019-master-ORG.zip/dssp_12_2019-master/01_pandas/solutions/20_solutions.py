sns.boxplot(data=df, y='Fare', x='Survived', hue='Sex', whis=1000)
