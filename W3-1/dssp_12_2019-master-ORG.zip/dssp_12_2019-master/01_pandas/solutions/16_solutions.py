df.groupby('Pclass')['Fare'].hist(alpha=0.4);
