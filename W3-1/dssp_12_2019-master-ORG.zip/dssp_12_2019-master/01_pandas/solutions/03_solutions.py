df = pd.DataFrame({'Country Name': country_name,
                   'Country Code': country_code,
                   2015: gdp_2015,
                   2017: gdp_2017})
df = df.set_index('Country Code')
df
