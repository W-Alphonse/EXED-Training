gdf_normalized.plot(column='Choice B')
