df[df['Sex'] == 'female']['Age'].mean()
