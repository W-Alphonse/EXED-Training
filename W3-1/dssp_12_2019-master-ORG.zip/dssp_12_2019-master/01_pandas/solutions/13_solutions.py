df['Fare'].hist()
