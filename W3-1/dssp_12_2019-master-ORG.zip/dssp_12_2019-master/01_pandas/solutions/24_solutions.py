df_referendum = pd.read_csv(filename_referendum, sep=';')
