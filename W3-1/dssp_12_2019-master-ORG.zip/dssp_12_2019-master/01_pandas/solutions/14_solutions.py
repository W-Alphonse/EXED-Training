df.groupby('Sex')['Age'].mean()
