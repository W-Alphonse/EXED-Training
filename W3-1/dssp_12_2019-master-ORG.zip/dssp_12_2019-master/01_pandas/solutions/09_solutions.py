df['Survived'].mean()
