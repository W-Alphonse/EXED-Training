x = np.ones((3, 3))
y = np.arange(3)
x + y
