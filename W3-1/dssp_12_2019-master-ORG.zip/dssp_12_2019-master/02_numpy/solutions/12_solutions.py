x = np.arange(3)
x + 5
