column_arr = arr.reshape(-1, 1)
column_arr = arr[np.newaxis, :]

row_arr = arr.reshape(1, -1)
row_arr = arr[:. np.newaxis]
