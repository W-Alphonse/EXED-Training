x = np.arange(3).reshape((3, 1))
y = np.arange(3)
x + y
