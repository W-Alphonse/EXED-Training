x = np.arange(-10, 10, 0.001)
f_x = 10 * np.cos(x) + x
