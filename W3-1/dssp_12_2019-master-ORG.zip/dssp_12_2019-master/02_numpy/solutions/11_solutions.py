col = data[:, 14]
col[col > 0]
