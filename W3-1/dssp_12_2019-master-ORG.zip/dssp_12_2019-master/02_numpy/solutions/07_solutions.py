arr = np.random.random(8)
print('Shape of the array', arr.shape)
arr_reshaped = arr.reshape((2, 2, 2))
print('Shape of the array', arr_reshaped.shape)
