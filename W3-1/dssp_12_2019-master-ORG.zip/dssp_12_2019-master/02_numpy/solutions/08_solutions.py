data[0, 9]
