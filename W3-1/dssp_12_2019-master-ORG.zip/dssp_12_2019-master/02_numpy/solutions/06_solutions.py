arr = np.logspace(0, 1, 10)
arr
