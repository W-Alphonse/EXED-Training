mul = np.dot(X, Y)
print(mul)
print('Shape of the resulting matrix', mul.shape)
