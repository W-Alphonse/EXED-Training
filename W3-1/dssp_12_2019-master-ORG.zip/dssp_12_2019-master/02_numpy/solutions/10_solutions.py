data[3, 2:15]
