arr = np.ones(100) * 0.1
arr
