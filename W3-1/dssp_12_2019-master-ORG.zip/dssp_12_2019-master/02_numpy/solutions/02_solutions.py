arr = np.array([1, 2, 3, 4, 5], dtype=np.float64)
print(arr)
print(arr.dtype)
