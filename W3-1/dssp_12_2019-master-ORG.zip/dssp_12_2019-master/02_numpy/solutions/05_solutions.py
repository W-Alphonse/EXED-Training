step_size = 3
arr = np.arange(0, 8 * step_size, step_size)
print(arr)
print('Number of element inside the array', arr.size)
