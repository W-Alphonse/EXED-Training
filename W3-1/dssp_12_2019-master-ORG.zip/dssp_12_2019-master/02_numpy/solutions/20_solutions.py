X = np.random.randn(10)
Y = np.random.randn(10)
print(np.hstack((X, Y)).shape)
print(np.vstack((X, Y)).shape)
