mul = X * Y
